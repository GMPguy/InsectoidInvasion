Got ya again, you won't preish if you don't read this.
So... you have decided to look into the source code. I pitty you, but before you do anything, read these info below:

1. You need a "Clickteam Fusion 2.5" program (equivelant or better) in order to open this .mfa file
2. You also need these extensions:
	-  "Layer object"
	- "Mouse object"